import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Send, Upload } from "lucide-react";

interface ChatInputProps {
  onSend: (content: string, model: string) => void;
  isLoading: boolean;
}

export default function ChatInput({ onSend, isLoading }: ChatInputProps) {
  const [content, setContent] = useState("");
  const [selectedModel, setSelectedModel] = useState("mistral");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSend = () => {
    if (content.trim()) {
      onSend(content, selectedModel);
      setContent("");
    }
  };

  return (
    <div className="flex gap-2">
      <input
        type="file"
        accept="image/*"
        className="hidden"
        ref={fileInputRef}
        onChange={(e) => {
          // Handle image upload
          const file = e.target.files?.[0];
          if (file) {
            setSelectedModel("llava");
            // Convert to base64 and send
            const reader = new FileReader();
            reader.onloadend = () => {
              onSend(reader.result as string, "llava");
            };
            reader.readAsDataURL(file);
          }
        }}
      />
      <Button
        variant="outline"
        size="icon"
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="h-4 w-4" />
      </Button>
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder="Ask a question..."
        className="flex-1"
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
          }
        }}
      />
      <Button onClick={handleSend} disabled={isLoading}>
        <Send className="h-4 w-4" />
      </Button>
    </div>
  );
}

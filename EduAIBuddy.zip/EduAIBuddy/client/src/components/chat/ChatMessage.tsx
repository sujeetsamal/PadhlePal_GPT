import { useState } from "react";
import { Message } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Volume2, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ChatMessageProps {
  message: Message;
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(message.content);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    toast({
      title: "Copied to clipboard",
      duration: 2000,
    });
  };

  const handleSpeak = () => {
    if (message.model === "mistral") {
      const speech = new SpeechSynthesisUtterance(message.content);
      window.speechSynthesis.speak(speech);
    }
  };

  return (
    <Card className={message.role === "user" ? "bg-primary/10" : "bg-card"}>
      <CardContent className="p-4">
        <div className="flex justify-between items-start gap-4">
          <div className="flex-1">
            {isEditing ? (
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                className="w-full p-2 rounded border"
                rows={3}
              />
            ) : (
              <p className="whitespace-pre-wrap">{message.content}</p>
            )}
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="icon" onClick={handleCopy}>
              <Copy className="h-4 w-4" />
            </Button>
            {message.role === "assistant" && message.model === "mistral" && (
              <Button variant="ghost" size="icon" onClick={handleSpeak}>
                <Volume2 className="h-4 w-4" />
              </Button>
            )}
            {message.role === "user" && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsEditing(!isEditing)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        <div className="mt-2 text-xs text-muted-foreground">
          {message.model} • {new Date(message.timestamp).toLocaleTimeString()}
        </div>
      </CardContent>
    </Card>
  );
}

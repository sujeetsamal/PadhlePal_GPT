import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ModelSelectorProps {
  value?: string;
  onChange?: (value: string) => void;
}

export default function ModelSelector({ value, onChange }: ModelSelectorProps) {
  return (
    <div className="mb-4">
      <Select
        value={value}
        onValueChange={onChange}
        defaultValue="mistral"
      >
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Select a model" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="mistral">Mistral (Academic)</SelectItem>
          <SelectItem value="codellama">CodeLlama (Code)</SelectItem>
          <SelectItem value="llava">LLaVA (Image Analysis)</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}

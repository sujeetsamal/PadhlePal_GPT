import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Message } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import ChatInput from "@/components/chat/ChatInput";
import ChatMessage from "@/components/chat/ChatMessage";
import ModelSelector from "@/components/chat/ModelSelector";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function Chat() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const messagesQuery = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    onError: () => setLocation("/login")
  });

  const chatMutation = useMutation({
    mutationFn: async ({ content, model }: { content: string, model: string }) => {
      const res = await apiRequest("POST", "/api/chat", { content, model });
      return res.json();
    },
    onSuccess: () => {
      messagesQuery.refetch();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Failed to send message",
        description: error.message
      });
    }
  });

  if (messagesQuery.isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      <div className="container mx-auto px-4 py-4 flex-1 flex flex-col">
        <ModelSelector />
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4 mb-4">
            {messagesQuery.data?.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
          </div>
        </ScrollArea>
        <ChatInput 
          onSend={(content, model) => chatMutation.mutate({ content, model })}
          isLoading={chatMutation.isPending}
        />
      </div>
    </div>
  );
}

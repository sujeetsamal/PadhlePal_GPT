import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center bg-background">
      <div className="max-w-3xl mx-auto text-center px-4">
        <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl">
          PadhlePal GPT
        </h1>
        <p className="mt-6 text-lg leading-8 text-muted-foreground">
          Your AI-powered educational companion. Get help with academics, learn coding, and analyze images - all in one place.
        </p>
        <div className="mt-10 flex items-center justify-center gap-x-6">
          <Link href="/login">
            <Button size="lg">Get Started</Button>
          </Link>
          <Link href="/register">
            <Button variant="outline" size="lg">Sign up</Button>
          </Link>
        </div>
      </div>
      
      {/* Matrix-like background */}
      <div className="fixed inset-0 -z-10 h-full w-full bg-background">
        <div className="absolute inset-0 bg-grid-white/10" 
             style={{
               backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 32 32'%3E%3Cpath d='M0 0h32v32H0z' fill='none'/%3E%3C/svg%3E")`,
               mask: 'linear-gradient(to bottom, transparent, black)'
             }} />
      </div>
    </div>
  );
}

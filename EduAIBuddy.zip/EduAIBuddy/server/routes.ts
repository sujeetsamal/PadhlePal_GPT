import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";
import { spawn } from "child_process";
import fetch from "node-fetch";

declare module "express-session" {
  interface SessionData {
    userId?: number;
  }
}

export function registerRoutes(app: Express): Server {
  const MemoryStoreSession = MemoryStore(session);

  // Session middleware
  app.use(session({
    secret: "padhlepal-secret",
    resave: false,
    saveUninitialized: false,
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // 24 hours
    })
  }));

  // Auth routes
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(userData);
      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      const isValid = await storage.validatePassword(username, password);
      
      if (!isValid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user) return res.status(401).json({ message: "User not found" });
      
      req.session.userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch (error) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post("/api/logout", (req, res) => {
    req.session.destroy(err => {
      if (err) {
        res.status(500).json({ message: "Error logging out" });
      } else {
        res.json({ message: "Logged out successfully" });
      }
    });
  });

  // Chat routes
  app.get("/api/messages", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const messages = await storage.getUserMessages(req.session.userId);
    res.json(messages);
  });

  app.post("/api/chat", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const { content, model } = req.body;
    
    // Store user message
    await storage.createMessage({
      userId: req.session.userId,
      content,
      role: "user",
      model
    });

    // Get response from Ollama
    const response = await fetch(`http://localhost:11434/api/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        prompt: content,
        stream: false
      })
    });

    const data = await response.json();
    
    // Store AI response
    const aiMessage = await storage.createMessage({
      userId: req.session.userId,
      content: data.response,
      role: "assistant",
      model
    });

    res.json(aiMessage);
  });

  const httpServer = createServer(app);
  return httpServer;
}
